# CS460-Tokenization
# To run, please type
# g++ Tokenization.cpp -std=c++17
# ./a.out programming_assignment_2-test_file_5.c
